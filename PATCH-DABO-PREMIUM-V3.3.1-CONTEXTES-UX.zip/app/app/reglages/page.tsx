"use client";

import { useState, useEffect } from "react";
import { LoadingState } from "@/components/LoadingState";
import { useRouter } from "next/navigation";
import { useHousehold } from "@/lib/use-household";
import {
  clearHouseholdOfflineContext,
  clearOfflineAuthenticatedUser,
} from "@/lib/household-offline-storage";
import { clearShoppingOfflineData } from "@/lib/shopping-offline-storage";
import { Header } from "@/components/Header";
import { DaboAppearanceControl } from "@/components/DaboAppearanceControl";
import { Avatar } from "@/components/Avatar";
import { Copy, LogOut, Bell, Check, UserMinus, ShieldPlus, Pencil, MoreHorizontal, Share2, ImagePlus, Download } from "lucide-react";
import { IntroTip } from "@/components/IntroTip";
import { enableNotifications, disableNotifications, requiresIosHomeScreenInstall } from "@/lib/notifications";
import { hasVerifiedPushSubscription, stopNotificationNudge } from "@/lib/notification-activation";
import { MEMBER_COLORS } from "@/lib/utils";
import { useLanguage, useT } from "@/lib/language-context";
import { countryOptions, detectIsoCountryFromDevice } from "@/lib/countries";
import { Lang } from "@/lib/i18n";
import { LANGUAGE_OPTIONS, isAvailableLang } from "@/lib/languages";
import { HouseholdSwitcher } from "@/components/HouseholdSwitcher";
import { setTutorialEnabled } from "@/lib/tutorial-preferences";
import { clearTutorialLocalStateForUser } from "@/lib/tutorial-local-storage";
import type { LifeContextImpact, LifeContextType, MemberLifeContext } from "@/lib/life-context";
import { shareDaboApp } from "@/lib/app-share";
import { markContextualShareShared } from "@/lib/contextual-share";
import { QRCodeSVG } from "qrcode.react";

type SettingsConfirmation =
  | { kind: "promote"; memberId: string; name: string }
  | { kind: "remove"; memberId: string; name: string }
  | { kind: "leave" }
  | { kind: "delete" };

const AVATAR_EMOJIS = ["🐶", "🐱", "🦊", "🐼", "🦁", "🐸", "🌿", "🌻", "🌙", "⭐", "🌊", "🔥"];
const MAX_AVATAR_SIZE = 5 * 1024 * 1024;
const AVATAR_MIME_EXTENSIONS: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/gif": "gif",
};
export default function SettingsPage() {
  const { loading, household, me, members, supabase, refresh } = useHousehold();
  const router = useRouter();
  const t = useT();
  const lang = useLanguage();
  const householdCountries = countryOptions(lang);
  const inviteUrl =
    household && typeof window !== "undefined"
      ? `${window.location.origin}/?invite=${encodeURIComponent(household.invite_code)}`
      : "";
  const [copied, setCopied] = useState(false);
  const [notifStatus, setNotifStatus] = useState<"idle" | "loading" | "done" | "error" | "checking" | "blocked" | "unsupported" | "ios-install">("checking");
  const [notifError, setNotifError] = useState("");
  const [firstName, setFirstName] = useState(me?.first_name || "");
  const [savingProfile, setSavingProfile] = useState(false);
  const [savingAvatar, setSavingAvatar] = useState(false);
  const [editingFirstName, setEditingFirstName] = useState(false);
  const [lifeContexts, setLifeContexts] = useState<MemberLifeContext[]>([]);
  const [lifeContextType, setLifeContextType] = useState<LifeContextType>("busy_period");
  const [lifeContextImpact, setLifeContextImpact] = useState<LifeContextImpact>("reduced");
  const [lifeContextStart, setLifeContextStart] = useState("");
  const [lifeContextEnd, setLifeContextEnd] = useState("");
  const [editingLifeContextId, setEditingLifeContextId] = useState<string | null>(null);
  const [savingLifeContext, setSavingLifeContext] = useState(false);
  const [householdName, setHouseholdName] = useState(household?.name || "");
  const [savingHouseholdName, setSavingHouseholdName] = useState(false);
  const [householdNameSaved, setHouseholdNameSaved] = useState(false);
  const [editingHouseholdName, setEditingHouseholdName] = useState(false);
  const [editingHouseholdType, setEditingHouseholdType] = useState(false);
  const [householdType, setHouseholdType] = useState(household?.household_type || "couple");
  const [householdCountry, setHouseholdCountry] = useState(household?.country_code || "BE");
  const [memberActionsId, setMemberActionsId] = useState<string | null>(null);
  const [householdDetailsOpen, setHouseholdDetailsOpen] = useState(false);
  const [inviteOpen, setInviteOpen] = useState(false);
  const [guideInvite, setGuideInvite] = useState(false);
  const [confirmation, setConfirmation] = useState<SettingsConfirmation | null>(null);
  const [confirmationLoading, setConfirmationLoading] = useState(false);
  const [deletePhrase, setDeletePhrase] = useState("");
  const [exportingData, setExportingData] = useState(false);
  const [feedback, setFeedback] = useState<{ type: "success" | "error"; text: string } | null>(null);

  function showFeedback(type: "success" | "error", text: string) {
    setFeedback({ type, text });
    window.setTimeout(() => setFeedback(null), 3500);
  }

  function closeConfirmation() {
    if (confirmationLoading) return;
    setConfirmation(null);
    setDeletePhrase("");
  }

  useEffect(() => {
    if (typeof window === "undefined") return;
    const guide = new URLSearchParams(window.location.search).get("guide");
    if (guide !== "invite") return;
    setInviteOpen(true);
    setGuideInvite(true);
    window.setTimeout(() => document.getElementById("dabo-invite-member")?.scrollIntoView({ behavior: "smooth", block: "center" }), 120);
  }, []);

  async function replayTutorial() {
    try {
      await setTutorialEnabled(supabase, true);
      const { data: userData } = await supabase.auth.getUser();
      if (userData.user?.id) clearTutorialLocalStateForUser(userData.user.id);
      showFeedback("success", t("tutorial_reenabled"));
    } catch {
      showFeedback("error", t("settings_error_save"));
    }
  }

  useEffect(() => {
    if (me) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setFirstName(me.first_name);
    }
  }, [me?.id]);

  useEffect(() => {
    if (!household || !me) return;

    let cancelled = false;

    void supabase
      .from("member_life_contexts")
      .select("*")
      .eq("household_id", household.id)
      .eq("member_id", me.id)
      .order("starts_on", { ascending: true })
      .then(({ data, error }) => {
        if (cancelled) return;
        if (error) {
          console.error("DABO life context load failed", error);
          return;
        }
        setLifeContexts((data as MemberLifeContext[]) || []);
      });

    return () => {
      cancelled = true;
    };
  }, [household?.id, me?.id, supabase]);

  useEffect(() => {
    if (household) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setHouseholdName(household.name);
      setHouseholdType(household.household_type);
      setHouseholdCountry(household.country_code || detectIsoCountryFromDevice());
    }
  }, [household?.id]);

  async function saveProfile() {
    if (!me || !firstName.trim()) return;
    setSavingProfile(true);
    const { error } = await supabase.from("members").update({ first_name: firstName.trim() }).eq("id", me.id);
    setSavingProfile(false);
    if (error) {
      showFeedback("error", t("settings_error_save"));
      return;
    }
    setEditingFirstName(false);
    refresh();
  }

  async function saveLifeContext() {
    if (
      !household ||
      !me ||
      !lifeContextStart ||
      !lifeContextEnd ||
      lifeContextEnd < lifeContextStart ||
      savingLifeContext
    ) {
      return;
    }

    setSavingLifeContext(true);

    try {
      const { data, error } = await supabase.rpc("save_member_life_context", {
        p_household_id: household.id,
        p_context_type: lifeContextType,
        p_impact: lifeContextImpact,
        p_starts_on: lifeContextStart,
        p_ends_on: lifeContextEnd,
        p_context_id: editingLifeContextId,
      });

      if (error) throw error;

      const contextId = String(data);
      const now = new Date().toISOString();

      const saved: MemberLifeContext = {
        id: contextId,
        household_id: household.id,
        member_id: me.id,
        context_type: lifeContextType,
        impact: lifeContextImpact,
        starts_on: lifeContextStart,
        ends_on: lifeContextEnd,
        created_at:
          lifeContexts.find((context) => context.id === contextId)?.created_at ??
          now,
        updated_at: now,
      };

      setLifeContexts((current) =>
        [...current.filter((context) => context.id !== contextId), saved].sort(
          (a, b) => a.starts_on.localeCompare(b.starts_on)
        )
      );

      setEditingLifeContextId(null);
      setLifeContextStart("");
      setLifeContextEnd("");
      setLifeContextType("busy_period");
      setLifeContextImpact("reduced");
      showFeedback("success", t("settings_life_context_saved"));
    } catch (error) {
      console.error("DABO life context save failed", error);
      showFeedback("error", t("settings_life_context_error"));
    } finally {
      setSavingLifeContext(false);
    }
  }

  async function deleteLifeContext(contextId: string) {
    if (!household || savingLifeContext) return;

    setSavingLifeContext(true);

    try {
      const { error } = await supabase.rpc("delete_member_life_context", {
        p_household_id: household.id,
        p_context_id: contextId,
      });

      if (error) throw error;

      setLifeContexts((current) =>
        current.filter((context) => context.id !== contextId)
      );

      if (editingLifeContextId === contextId) {
        setEditingLifeContextId(null);
        setLifeContextStart("");
        setLifeContextEnd("");
        setLifeContextType("busy_period");
        setLifeContextImpact("reduced");
      }

      showFeedback("success", t("settings_life_context_deleted"));
    } catch (error) {
      console.error("DABO life context delete failed", error);
      showFeedback("error", t("settings_life_context_error"));
    } finally {
      setSavingLifeContext(false);
    }
  }

  function editLifeContext(context: MemberLifeContext) {
    setEditingLifeContextId(context.id);
    setLifeContextType(context.context_type);
    setLifeContextImpact(context.impact);
    setLifeContextStart(context.starts_on);
    setLifeContextEnd(context.ends_on);
  }

  async function chooseColor(color: string) {
    if (!me) return;
    const { error } = await supabase.from("members").update({ avatar_color: color }).eq("id", me.id);
    if (error) {
      showFeedback("error", t("settings_error_save"));
      return;
    }
    refresh();
  }

  async function removePreviousAvatar(path: string | null | undefined) {
    if (path) await supabase.storage.from("member-avatars").remove([path]);
  }

  async function chooseAvatarEmoji(emoji: string | null) {
    if (!me || savingAvatar) return;
    setSavingAvatar(true);
    const previousPath = me.avatar_path;
    const { error } = await supabase
      .from("members")
      .update({ avatar_emoji: emoji, avatar_url: null, avatar_path: null })
      .eq("id", me.id);
    if (error) {
      showFeedback("error", t("settings_avatar_error_save"));
      setSavingAvatar(false);
      return;
    }
    await removePreviousAvatar(previousPath);
    await refresh();
    setSavingAvatar(false);
  }

  async function uploadAvatar(file: File | undefined) {
    if (!me || !file || savingAvatar) return;
    const extension = AVATAR_MIME_EXTENSIONS[file.type];
    if (!extension) {
      showFeedback("error", t("settings_avatar_error_type"));
      return;
    }
    if (file.size > MAX_AVATAR_SIZE) {
      showFeedback("error", t("settings_avatar_error_size"));
      return;
    }

    setSavingAvatar(true);
    const { data: userData } = await supabase.auth.getUser();
    const userId = userData.user?.id;
    if (!userId) {
      showFeedback("error", t("settings_error_session"));
      setSavingAvatar(false);
      return;
    }

    // Un dossier par compte puis par profil de foyer : une personne peut donc
    // conserver un avatar différent dans chacun de ses foyers sans collision.
    const path = `${userId}/${me.id}/${Date.now()}.${extension}`;
    const { error: uploadError } = await supabase.storage
      .from("member-avatars")
      .upload(path, file, { cacheControl: "3600", upsert: false, contentType: file.type });

    if (uploadError) {
      showFeedback("error", t("settings_avatar_error_upload"));
      setSavingAvatar(false);
      return;
    }

    const previousPath = me.avatar_path;
    const { error: updateError } = await supabase
      .from("members")
      .update({ avatar_path: path, avatar_url: null, avatar_emoji: null })
      .eq("id", me.id);

    if (updateError) {
      await supabase.storage.from("member-avatars").remove([path]);
      showFeedback("error", t("settings_avatar_error_save"));
      setSavingAvatar(false);
      return;
    }

    await removePreviousAvatar(previousPath);
    await refresh();
    showFeedback("success", t("settings_avatar_saved"));
    setSavingAvatar(false);
  }

  async function chooseLanguage(lang: Lang) {
    if (!me) return;
    const { error } = await supabase.from("members").update({ language: lang }).eq("id", me.id);
    if (error) {
      showFeedback("error", t("settings_error_save"));
      return;
    }
    refresh();
  }

  async function shareApp() {
    const result = await shareDaboApp({
      supabase,
      householdId: household?.id || null,
      message: t("share_app_message"),
    });

    if (result.outcome === "shared") {
      if (me?.user_id && household?.id) {
        markContextualShareShared(me.user_id, household.id);
      }

      if (result.method === "clipboard") {
        showFeedback("success", t("share_app_copied"));
      }
    } else if (result.outcome === "error") {
      showFeedback("error", t("settings_error_copy"));
    }
  }

  useEffect(() => {
    (async () => {
      if (requiresIosHomeScreenInstall()) {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setNotifStatus("ios-install");
        return;
      }
      if (!("Notification" in window) || !("serviceWorker" in navigator) || !("PushManager" in window)) {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setNotifStatus("unsupported");
        return;
      }
      if (Notification.permission === "denied") {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setNotifStatus("blocked");
        return;
      }
      if (Notification.permission !== "granted") {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setNotifStatus("idle");
        return;
      }
      const verifiedSubscription = me ? await hasVerifiedPushSubscription(supabase, me.id) : false;
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setNotifStatus(verifiedSubscription ? "done" : "idle");
    })();
  }, [me, supabase]);

  async function handleEnableNotifications() {
    if (!me) return;
    setNotifStatus("loading");
    setNotifError("");
    try {
      await enableNotifications(supabase, me.id);
      const verifiedSubscription = await hasVerifiedPushSubscription(supabase, me.id);
      if (!verifiedSubscription) throw new Error("Push subscription not persisted");
      setNotifStatus("done");
    } catch {
      if ("Notification" in window && Notification.permission === "denied") {
        setNotifStatus("blocked");
        return;
      }
      setNotifError(t("settings_notifications_error"));
      setNotifStatus("error");
    }
  }

  async function handleDisableNotifications() {
    setNotifStatus("loading");
    setNotifError("");
    try {
      await disableNotifications(supabase);
      if (me?.user_id) stopNotificationNudge(me.user_id);
      setNotifStatus("idle");
    } catch {
      setNotifError(t("settings_notifications_error"));
      setNotifStatus("error");
    }
  }

  async function toggleEquity() {
    if (!household) return;
    const { error } = await supabase.from("households").update({ equity_score_enabled: !household.equity_score_enabled }).eq("id", household.id);
    if (error) {
      showFeedback("error", t("settings_error_save"));
      return;
    }
    refresh();
  }
  async function saveHouseholdCountry() {
    if (!household) return;
    const { error } = await supabase.from("households").update({ country_code: householdCountry }).eq("id", household.id);
    if (error) {
      showFeedback("error", t("settings_error_save"));
      return;
    }
    showFeedback("success", t("settings_country_saved"));
    refresh();
  }

  async function saveHouseholdType() {
    if (!household) return;
    const { error } = await supabase.from("households").update({ household_type: householdType }).eq("id", household.id);
    if (error) {
      showFeedback("error", t("settings_error_save"));
      return;
    }
    setEditingHouseholdType(false);
    refresh();
  }
  async function saveHouseholdName() {
    if (!household || !householdName.trim()) return;
    setSavingHouseholdName(true);
    const { error } = await supabase.from("households").update({ name: householdName.trim() }).eq("id", household.id);
    setSavingHouseholdName(false);
    if (error) {
      showFeedback("error", t("settings_error_save"));
      return;
    }
    setHouseholdNameSaved(true);
    setEditingHouseholdName(false);
    setTimeout(() => setHouseholdNameSaved(false), 1500);
    refresh();
  }
  async function copyCode() {
    if (!household) return;
    try {
      if (!navigator.clipboard) throw new Error("Clipboard unavailable");
      await navigator.clipboard.writeText(household.invite_code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      showFeedback("error", t("settings_error_copy"));
    }
  }
  async function shareInvite() {
    if (!household) return;
    const text = t("settings_invite_share_message")
      .replace("{household}", household.name);
    if (navigator.share) {
      try {
        await navigator.share({ title: "DABO", text, url: inviteUrl });
      } catch {
        // Partage annulé — rien à faire.
      }
      return;
    }
    try {
      if (!navigator.clipboard) throw new Error("Clipboard unavailable");
      await navigator.clipboard.writeText(`${text} ${inviteUrl}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      showFeedback("error", t("settings_error_copy"));
    }
  }
  async function removeMember(memberId: string) {
    const { data } = await supabase.auth.getSession();
    if (!data.session) {
      showFeedback("error", t("settings_error_session"));
      return false;
    }
    const res = await fetch("/api/remove-member", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${data.session.access_token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ memberId }),
    });
    if (!res.ok) {
      showFeedback("error", t("settings_error_remove_member"));
      return false;
    }
    await refresh();
    showFeedback("success", t("settings_member_removed"));
    return true;
  }

  async function promoteToCreator(memberId: string) {
    const { data } = await supabase.auth.getSession();
    if (!data.session) {
      showFeedback("error", t("settings_error_session"));
      return false;
    }

    const res = await fetch("/api/promote-member", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${data.session.access_token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ memberId }),
    });

    if (!res.ok) {
      showFeedback("error", t("settings_error_promote"));
      return false;
    }

    await refresh();
    showFeedback("success", t("settings_creator_updated"));
    return true;
  }

  async function leaveHousehold() {
    const { data } = await supabase.auth.getSession();
    if (!data.session) {
      showFeedback("error", t("settings_error_session"));
      return false;
    }
    const res = await fetch("/api/leave-household", {
      method: "POST",
      headers: { Authorization: `Bearer ${data.session.access_token}`, "Content-Type": "application/json" },
      body: JSON.stringify({ memberId: me?.id }),
    });
    if (!res.ok) {
      showFeedback("error", t("settings_error_leave"));
      return false;
    }
    router.replace("/");
    return true;
  }

  async function exportMyData(format: "readable" | "json") {
    if (exportingData) return;

    setExportingData(true);

    try {
      const { data } = await supabase.auth.getSession();

      if (!data.session) {
        showFeedback("error", t("settings_error_session"));
        return;
      }

      const endpoint =
        format === "readable"
          ? `/api/export-data?format=readable&lang=${encodeURIComponent(lang)}`
          : "/api/export-data";

      const res = await fetch(endpoint, {
        method: "GET",
        headers: {
          Authorization: "Bearer " + data.session.access_token,
        },
        cache: "no-store",
      });

      if (!res.ok) {
        showFeedback("error", t("settings_export_error"));
        return;
      }

      const blob = await res.blob();
      const disposition = res.headers.get("content-disposition");
      const filenameMatch = disposition?.match(/filename="([^"]+)"/i);
      const fallbackFilename =
        format === "readable" ? "dabo-data.html" : "dabo-data.json";
      const filename = filenameMatch?.[1] || fallbackFilename;

      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);

      showFeedback("success", t("settings_export_success"));
    } catch (error) {
      console.error("DABO portability download failed", error);
      showFeedback("error", t("settings_export_error"));
    } finally {
      setExportingData(false);
    }
  }

  async function signOut() {
    const { data } = await supabase.auth.getSession();

    if (data.session) {
      try {
        await clearHouseholdOfflineContext(data.session.user.id);
        await clearOfflineAuthenticatedUser();

        if (household?.id) {
          await clearShoppingOfflineData(household.id);
        }
      } catch (error) {
        console.error("[DABO] offline sign out cleanup failed", error);
      }
    }

    await supabase.auth.signOut();
    router.replace("/");
  }

  async function deleteAccount() {
    const { data } = await supabase.auth.getSession();
    if (!data.session) {
      showFeedback("error", t("settings_error_session"));
      return false;
    }
    const res = await fetch("/api/delete-account", {
      method: "POST",
      headers: { Authorization: `Bearer ${data.session.access_token}` },
    });
    if (!res.ok) {
      showFeedback("error", t("settings_error_delete_account"));
      return false;
    }

    try {
      await clearHouseholdOfflineContext(data.session.user.id);
      await clearOfflineAuthenticatedUser();

      if (household?.id) {
        await clearShoppingOfflineData(household.id);
      }
    } catch (error) {
      console.error("[DABO] offline account deletion cleanup failed", error);
    }

    await supabase.auth.signOut();
    router.replace("/");
    return true;
  }

  async function confirmSensitiveAction() {
    if (!confirmation) return;
    setConfirmationLoading(true);
    let completed = false;
    if (confirmation.kind === "promote") completed = await promoteToCreator(confirmation.memberId);
    if (confirmation.kind === "remove") completed = await removeMember(confirmation.memberId);
    if (confirmation.kind === "leave") completed = await leaveHousehold();
    if (confirmation.kind === "delete") completed = await deleteAccount();
    setConfirmationLoading(false);
    if (completed) {
      setConfirmation(null);
      setDeletePhrase("");
    }
  }

  if (loading || !household || !me) return <LoadingState />;

  const householdTypeLabel = household.household_type === "solo"
    ? t("household_solo")
    : household.household_type === "couple"
      ? t("household_couple")
      : household.household_type === "coloc"
        ? t("household_coloc")
        : t("household_famille");

  return (
    <div>
      <Header title={t("settings_title")} />
      <IntroTip id="settings" text={t("intro_settings")} />

      <div className="px-5 pb-8 space-y-7">
        <HouseholdSwitcher />
        <section>
          <div className="mb-3">
            <h2 className="text-base font-semibold text-ink">{t("settings_my_profile")}</h2>
            <p className="text-xs text-muted mt-0.5">{t("settings_profile_desc")}</p>
          </div>
          <div className="bg-white2 rounded-2xl p-4">
            <div className="flex items-center gap-3 mb-4">
              <Avatar member={me} members={members} size={42} />
              <div className="min-w-0">
                <div className="text-sm font-semibold text-ink truncate">{me.first_name}</div>
                <div className="text-xs text-muted">{me.role === "creator" ? t("settings_household_creator") : t("settings_member")}</div>
              </div>
            </div>
            <div className="border-t border-border pt-3 mb-4">
              <div className="text-xs text-muted mb-1">{t("settings_first_name")}</div>
              {editingFirstName ? (
                <div>
                  <input
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    autoFocus
                    className="w-full border border-border rounded-xl px-3 py-2 text-sm outline-none focus:border-ink bg-white2 text-ink"
                  />
                  <div className="flex gap-2 mt-2">
                    <button
                      onClick={() => {
                        setFirstName(me.first_name);
                        setEditingFirstName(false);
                      }}
                      disabled={savingProfile}
                      className="px-3 py-2 rounded-xl text-xs border border-border text-muted disabled:opacity-50"
                    >
                      {t("cancel")}
                    </button>
                    <button
                      onClick={saveProfile}
                      disabled={savingProfile || !firstName.trim()}
                      className="px-3 py-2 rounded-xl text-xs font-medium bg-ink text-paper disabled:opacity-50"
                    >
                      {savingProfile ? "..." : t("save")}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-between gap-3">
                  <div className="text-sm font-semibold text-ink truncate">{me.first_name}</div>
                  <button
                    onClick={() => {
                      setFirstName(me.first_name);
                      setEditingFirstName(true);
                    }}
                    className="inline-flex items-center gap-1.5 text-xs text-muted hover:text-ink transition-colors shrink-0"
                  >
                    <Pencil size={13} />
                    {t("edit")}
                  </button>
                </div>
              )}
            </div>
            <div className="border-t border-border pt-3 mb-4">
              <div className="text-xs text-muted mb-1">{t("settings_avatar_title")}</div>
              <div className="text-xs text-muted mb-3">{t("settings_avatar_desc")}</div>
              <div className="grid grid-cols-6 gap-2 mb-3">
                {AVATAR_EMOJIS.map((emoji) => (
                  <button
                    key={emoji}
                    type="button"
                    onClick={() => chooseAvatarEmoji(emoji)}
                    disabled={savingAvatar}
                    className={`h-11 rounded-xl border text-xl flex items-center justify-center transition-colors disabled:opacity-50 ${me.avatar_emoji === emoji && !me.avatar_path && !me.avatar_url ? "border-gold bg-gold/10" : "border-border"}`}
                    aria-label={`${t("settings_avatar_choose")} ${emoji}`}
                    aria-pressed={me.avatar_emoji === emoji && !me.avatar_path && !me.avatar_url}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
              <div className="flex flex-wrap gap-2">
                <label className={`inline-flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium bg-ink text-paper cursor-pointer ${savingAvatar ? "opacity-50 pointer-events-none" : ""}`}>
                  <ImagePlus size={14} />
                  {savingAvatar ? t("settings_avatar_saving") : t("settings_avatar_upload")}
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp,image/gif"
                    className="sr-only"
                    disabled={savingAvatar}
                    onChange={(event) => {
                      void uploadAvatar(event.target.files?.[0]);
                      event.target.value = "";
                    }}
                  />
                </label>
                {(me.avatar_path || me.avatar_url || me.avatar_emoji) && (
                  <button
                    type="button"
                    onClick={() => chooseAvatarEmoji(null)}
                    disabled={savingAvatar}
                    className="px-3 py-2 rounded-xl text-xs border border-border text-muted disabled:opacity-50"
                  >
                    {t("settings_avatar_use_initials")}
                  </button>
                )}
              </div>
              <div className="text-[11px] text-muted mt-2">{t("settings_avatar_formats")}</div>
            </div>
            <div className="text-xs text-muted mb-2">{t("settings_avatar_color")}</div>
            <div className="flex gap-2 mb-4 flex-wrap">
              {MEMBER_COLORS.map((c) => (
                <button
                  key={c}
                  onClick={() => chooseColor(c)}
                  className="w-8 h-8 rounded-full flex items-center justify-center"
                  style={{ background: c }}
                  aria-label={t("settings_avatar_color")}
                  aria-pressed={me.avatar_color === c}
                >
                  {me.avatar_color === c && <Check size={14} color="#F0EFE6" />}
                </button>
              ))}
            </div>
            <label htmlFor="dabo-language" className="text-xs text-muted mb-2 block">{t("settings_language")}</label>
            <select
              id="dabo-language"
              value={me.language}
              onChange={(event) => {
                if (isAvailableLang(event.target.value)) void chooseLanguage(event.target.value);
              }}
              className="w-full border border-border rounded-xl px-3 py-2.5 text-sm outline-none focus:border-ink bg-white2 text-ink mb-2"
            >
              {LANGUAGE_OPTIONS.map((language) => (
                <option key={language.code} value={language.code} disabled={!language.available}>
                  {language.nativeLabel}{language.available ? "" : ` — ${t("settings_language_coming_soon")}`}
                </option>
              ))}
            </select>
            <div className="text-[11px] leading-4 text-muted mb-4">{t("settings_language_hint")}</div>

            <div className="border-t border-border pt-4 mt-4">
              <div className="text-sm font-semibold text-ink">
                {t("settings_life_context_title")}
              </div>
              <p className="text-xs leading-5 text-muted mt-1 mb-4">
                {t("settings_life_context_desc")}
              </p>

              {lifeContexts.length > 0 && (
                <div className="space-y-2 mb-4">
                  {lifeContexts.map((context) => {
                    const today = new Date();
                    const localToday =
                      `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
                    const isActive =
                      context.starts_on <= localToday &&
                      context.ends_on >= localToday;
                    const isUpcoming = context.starts_on > localToday;

                    return (
                      <div
                        key={context.id}
                        className="rounded-xl border border-border bg-paper/60 p-3"
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0">
                            {(isActive || isUpcoming) && (
                              <div className="text-[10px] uppercase tracking-wide text-muted mb-1">
                                {isActive
                                  ? t("settings_life_context_active")
                                  : t("settings_life_context_upcoming")}
                              </div>
                            )}
                            <div className="text-sm font-medium text-ink">
                              {t(
                                `settings_life_context_${context.context_type}`
                              )}
                            </div>
                            <div className="text-xs text-muted mt-1">
                              {t(
                                `settings_life_context_impact_${context.impact}`
                              )}
                              {" · "}
                              {context.starts_on}
                              {" → "}
                              {context.ends_on}
                            </div>
                          </div>

                          <div className="flex gap-2 shrink-0">
                            <button
                              type="button"
                              onClick={() => editLifeContext(context)}
                              disabled={savingLifeContext}
                              className="text-xs text-muted hover:text-ink disabled:opacity-50"
                            >
                              {t("edit")}
                            </button>
                            <button
                              type="button"
                              onClick={() => void deleteLifeContext(context.id)}
                              disabled={savingLifeContext}
                              className="text-xs text-muted hover:text-ink disabled:opacity-50"
                            >
                              {t("settings_life_context_delete")}
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              <div className="space-y-3">
                <div>
                  <label
                    htmlFor="life-context-type"
                    className="text-xs text-muted mb-1 block"
                  >
                    {t("settings_life_context_title")}
                  </label>
                  <select
                    id="life-context-type"
                    value={lifeContextType}
                    onChange={(event) =>
                      setLifeContextType(event.target.value as LifeContextType)
                    }
                    disabled={savingLifeContext}
                    className="w-full border border-border rounded-xl px-3 py-2.5 text-sm outline-none focus:border-ink bg-white2 text-ink disabled:opacity-50"
                  >
                    <option value="busy_period">
                      {t("settings_life_context_busy_period")}
                    </option>
                    <option value="studies">
                      {t("settings_life_context_studies")}
                    </option>
                    <option value="travel">
                      {t("settings_life_context_travel")}
                    </option>
                    <option value="away">
                      {t("settings_life_context_away")}
                    </option>
                    <option value="reduced_availability">
                      {t("settings_life_context_reduced_availability")}
                    </option>
                    <option value="other">
                      {t("settings_life_context_other")}
                    </option>
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="life-context-impact"
                    className="text-xs text-muted mb-1 block"
                  >
                    {t("settings_life_context_impact")}
                  </label>
                  <select
                    id="life-context-impact"
                    value={lifeContextImpact}
                    onChange={(event) =>
                      setLifeContextImpact(
                        event.target.value as LifeContextImpact
                      )
                    }
                    disabled={savingLifeContext}
                    className="w-full border border-border rounded-xl px-3 py-2.5 text-sm outline-none focus:border-ink bg-white2 text-ink disabled:opacity-50"
                  >
                    <option value="reduced">
                      {t("settings_life_context_impact_reduced")}
                    </option>
                    <option value="very_reduced">
                      {t("settings_life_context_impact_very_reduced")}
                    </option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label
                      htmlFor="life-context-start"
                      className="text-xs text-muted mb-1 block"
                    >
                      {t("settings_life_context_start")}
                    </label>
                    <input
                      id="life-context-start"
                      type="date"
                      value={lifeContextStart}
                      onChange={(event) =>
                        setLifeContextStart(event.target.value)
                      }
                      disabled={savingLifeContext}
                      className="w-full border border-border rounded-xl px-3 py-2.5 text-sm outline-none focus:border-ink bg-white2 text-ink disabled:opacity-50"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="life-context-end"
                      className="text-xs text-muted mb-1 block"
                    >
                      {t("settings_life_context_end")}
                    </label>
                    <input
                      id="life-context-end"
                      type="date"
                      min={lifeContextStart || undefined}
                      value={lifeContextEnd}
                      onChange={(event) =>
                        setLifeContextEnd(event.target.value)
                      }
                      disabled={savingLifeContext}
                      className="w-full border border-border rounded-xl px-3 py-2.5 text-sm outline-none focus:border-ink bg-white2 text-ink disabled:opacity-50"
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => void saveLifeContext()}
                  disabled={
                    savingLifeContext ||
                    !lifeContextStart ||
                    !lifeContextEnd ||
                    lifeContextEnd < lifeContextStart
                  }
                  className="w-full rounded-xl bg-ink text-paper px-3 py-2.5 text-sm font-medium disabled:opacity-50"
                >
                  {savingLifeContext
                    ? "..."
                    : t("settings_life_context_save")}
                </button>
              </div>
            </div>
          </div>
        </section>

        <section>
          <div className="mb-3">
            <h2 className="text-base font-semibold text-ink">{t("settings_section_household")}</h2>
            <p className="text-xs text-muted mt-0.5">{t("settings_household_desc")}</p>
          </div>

          <div className="bg-white2 rounded-2xl p-4 mb-3">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="text-base font-semibold text-ink truncate">{household.name}</div>
                <div className="text-xs text-muted mt-0.5">{householdTypeLabel} · {members.length} {members.length === 1 ? t("settings_member_singular") : t("settings_member_plural")}</div>
              </div>
              <button
                onClick={() => setHouseholdDetailsOpen((open) => !open)}
                className="inline-flex items-center gap-1.5 text-xs text-muted shrink-0 px-1 py-1"
                aria-expanded={householdDetailsOpen}
              >
                <Pencil size={13} /> {t("settings_edit")}
              </button>
            </div>

            {householdDetailsOpen && (
              <div className="mt-4 border-t border-border">
                <div className="py-3">
                  {!editingHouseholdName ? (
                    <div className="flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <div className="text-xs text-muted">{t("settings_household_name")}</div>
                        <div className="text-sm text-ink font-medium truncate mt-0.5">{household.name}</div>
                      </div>
                      <button onClick={() => { setHouseholdName(household.name); setEditingHouseholdName(true); }} className="flex items-center gap-1.5 text-xs text-muted shrink-0">
                        <Pencil size={13} /> {t("settings_edit")}
                      </button>
                    </div>
                  ) : (
                    <div>
                      <div className="text-xs font-medium text-ink mb-1.5">{t("settings_household_name")}</div>
                      <input value={householdName} onChange={(e) => setHouseholdName(e.target.value)} className="w-full border border-border rounded-xl px-3 py-2 text-sm outline-none focus:border-ink mb-2 bg-white2 text-ink" autoFocus />
                      <div className="flex gap-2">
                        <button onClick={saveHouseholdName} disabled={savingHouseholdName || !householdName.trim()} className="bg-ink text-paper rounded-xl px-4 py-2 text-sm font-medium disabled:opacity-50">{savingHouseholdName ? "..." : householdNameSaved ? t("saved") : t("save")}</button>
                        <button onClick={() => { setHouseholdName(household.name); setEditingHouseholdName(false); }} className="px-3 py-2 text-sm text-muted">{t("cancel")}</button>
                      </div>
                    </div>
                  )}
                </div>

                <div className="py-3 border-t border-border">
                  {!editingHouseholdType ? (
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <div className="text-xs text-muted">{t("settings_household_type")}</div>
                        <div className="text-sm text-ink font-medium mt-0.5">{householdTypeLabel}</div>
                      </div>
                      <button onClick={() => { setHouseholdType(household.household_type);
      setHouseholdCountry(household.country_code || detectIsoCountryFromDevice()); setEditingHouseholdType(true); }} className="flex items-center gap-1.5 text-xs text-muted shrink-0">
                        <Pencil size={13} /> {t("settings_edit")}
                      </button>
                    </div>
                  ) : (
                    <div>
                      <div className="text-xs font-medium text-ink mb-1.5">{t("settings_household_type")}</div>
                      <select value={householdType} onChange={(e) => setHouseholdType(e.target.value as "solo" | "couple" | "coloc" | "famille")} className="w-full border border-border rounded-xl px-3 py-2 text-sm outline-none focus:border-ink bg-white2 text-ink mb-2">
                        <option value="solo">{t("household_solo")}</option>
                        <option value="couple">{t("household_couple")}</option>
                        <option value="coloc">{t("household_coloc")}</option>
                        <option value="famille">{t("household_famille")}</option>
                      </select>
                      <div className="flex gap-2">
                        <button onClick={saveHouseholdType} className="bg-ink text-paper rounded-xl px-4 py-2 text-sm font-medium">{t("save")}</button>
                        <button onClick={() => { setHouseholdType(household.household_type);
      setHouseholdCountry(household.country_code || detectIsoCountryFromDevice()); setEditingHouseholdType(false); }} className="px-3 py-2 text-sm text-muted">{t("cancel")}</button>
                      </div>
                    </div>
                  )}
                </div>

                <div className="py-3 border-t border-border">
                  <div className="text-xs font-medium text-ink mb-1.5">{t("settings_household_country")}</div>
                  <p className="text-xs text-muted mb-2">{t("settings_household_country_hint")}</p>
                  <div className="flex gap-2">
                    <select value={householdCountry} onChange={(e) => setHouseholdCountry(e.target.value)} className="flex-1 border border-border rounded-xl px-3 py-2 text-sm outline-none focus:border-ink bg-white2 text-ink">
                      {householdCountries.map((country) => <option key={country.code} value={country.code}>{country.name}</option>)}
                    </select>
                    <button onClick={saveHouseholdCountry} className="bg-ink text-paper rounded-xl px-4 py-2 text-sm font-medium">{t("save")}</button>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div id="dabo-invite-member" className={`bg-white2 rounded-2xl p-4 mb-3 transition-shadow ${guideInvite ? "ring-2 ring-mustard ring-offset-2 ring-offset-paper" : ""}`}>
            {guideInvite && <div className="text-xs font-semibold text-mustard mb-2">{t("tutorial_here_invite")}</div>}
            {!inviteOpen ? (
              <button
                onClick={() => setInviteOpen(true)}
                className="w-full text-sm text-ink font-medium flex items-center justify-between gap-3"
                aria-expanded={inviteOpen}
              >
                <span>+ {t("settings_invite_member")}</span>
                <span className="text-muted" aria-hidden="true">›</span>
              </button>
            ) : (
              <div>
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div>
                    <div className="text-sm text-ink font-medium mb-1">{t("settings_invite_member")}</div>
                    <p className="text-xs text-muted">{t("settings_invite_desc")}</p>
                  </div>
                  <button onClick={() => setInviteOpen(false)} className="text-xs text-muted px-1 py-1">{t("cancel")}</button>
                </div>
                <div className="flex items-center justify-between bg-paper rounded-xl px-3 py-2 mb-3">
                  <span className="font-mono text-sm text-ink tracking-wider">{household.invite_code}</span>
                  <button onClick={copyCode} className="flex items-center gap-1 text-xs text-muted">
                    <Copy size={14} /> {copied ? t("copied") : t("copy")}
                  </button>
                </div>
                {inviteUrl && (
                  <div className="mb-3 rounded-xl border border-border bg-paper p-4 text-center">
                    <div className="mb-1 text-sm font-medium text-ink">
                      {t("settings_invite_qr_title")}
                    </div>
                    <p className="mb-3 text-xs text-muted">
                      {t("settings_invite_qr_hint")}
                    </p>
                    <div className="mx-auto flex w-fit items-center justify-center rounded-xl bg-white p-2">
                      <QRCodeSVG
                        value={inviteUrl}
                        size={176}
                        level="M"
                        marginSize={4}
                        title={t("settings_invite_qr_title")}
                      />
                    </div>
                  </div>
                )}
                <button onClick={shareInvite} className="w-full border border-border rounded-xl px-3 py-2.5 text-sm text-ink font-medium flex items-center justify-center gap-2">
                  <Share2 size={15} /> {t("settings_share_invite")}
                </button>
              </div>
            )}
          </div>

          <button onClick={() => void replayTutorial()} className="w-full mb-3 border border-border bg-white2 rounded-2xl px-4 py-3 text-sm text-ink font-medium text-left">
            {t("tutorial_replay")}
          </button>

          <div id="dabo-members" className="bg-white2 rounded-2xl p-4 scroll-mt-6">
            <div className="text-sm font-medium text-ink mb-3">{t("settings_members")}</div>
            <div className="space-y-1">
              {members.map((m) => {
                const canManage = me.role === "creator" && m.id !== me.id;
                const actionsOpen = memberActionsId === m.id;
                return (
                  <div key={m.id} className="border-b border-border last:border-b-0 py-2.5">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Avatar member={m} members={members} size={32} />
                        <div className="min-w-0">
                          <div className="text-sm text-ink font-medium truncate">{m.first_name}{m.id === me.id ? ` · ${t("settings_you")}` : ""}</div>
                          <div className="text-xs text-muted">{m.role === "creator" ? t("settings_household_creator") : t("settings_member")}</div>
                        </div>
                      </div>
                      {canManage && (
                        <button onClick={() => setMemberActionsId(actionsOpen ? null : m.id)} className="p-2 text-muted rounded-lg" aria-label={t("settings_member_actions")}>
                          <MoreHorizontal size={18} />
                        </button>
                      )}
                    </div>
                    {canManage && actionsOpen && (
                      <div className="mt-3 ml-10 rounded-xl bg-paper p-2 space-y-1">
                        {m.role !== "creator" && (
                          <button onClick={() => { setMemberActionsId(null); setConfirmation({ kind: "promote", memberId: m.id, name: m.first_name }); }} className="w-full px-2.5 py-2 text-sm text-ink text-left flex items-center gap-2 rounded-lg">
                            <ShieldPlus size={15} className="text-muted" /> {t("promote_creator")}
                          </button>
                        )}
                        <button onClick={() => { setMemberActionsId(null); setConfirmation({ kind: "remove", memberId: m.id, name: m.first_name }); }} className="w-full px-2.5 py-2 text-sm text-red-700/80 text-left flex items-center gap-2 rounded-lg">
                          <UserMinus size={15} /> {t("settings_remove_member")}
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        <section>
          <div className="mb-3">
            <h2 className="text-base font-semibold text-ink">{t("settings_section_preferences")}</h2>
            <p className="text-xs text-muted mt-0.5">{t("settings_preferences_desc")}</p>
          </div>
          <div className="space-y-3">
            <div className="dabo-v331-appearance-setting bg-white2 rounded-2xl p-4 flex items-center justify-between gap-4">
              <div>
                <div className="text-sm text-ink font-medium">{({fr:"Apparence",nl:"Weergave",en:"Appearance",de:"Darstellung",es:"Apariencia",it:"Aspetto",pt:"Aparência"} as Record<string,string>)[me.language || "fr"] || "Apparence"}</div>
                <div className="text-xs text-muted">{({fr:"Choisissez l’ambiance qui vous convient.",nl:"Kies de weergave die bij u past.",en:"Choose the appearance that suits you.",de:"Wählen Sie Ihre bevorzugte Darstellung.",es:"Elige la apariencia que prefieras.",it:"Scegli l’aspetto che preferisci.",pt:"Escolha a aparência que prefere."} as Record<string,string>)[me.language || "fr"] || "Choisissez l’ambiance qui vous convient."}</div>
              </div>
              <DaboAppearanceControl legacyDark={!!me.dark_mode} />
            </div>
            <div className="bg-white2 rounded-2xl p-4 flex items-center justify-between gap-4">
              <div>
                <div className="text-sm text-ink font-medium">{t("settings_equity_toggle")}</div>
                <div className="text-xs text-muted">{t("settings_equity_toggle_desc")}</div>
              </div>
              <button onClick={toggleEquity} role="switch" aria-checked={household.equity_score_enabled} aria-label={t("settings_equity_toggle")} className={`w-11 h-6 rounded-full relative transition-colors shrink-0 ${household.equity_score_enabled ? "bg-ink" : "bg-border"}`}>
                <span className={`absolute top-0.5 w-5 h-5 bg-paper rounded-full transition-all ${household.equity_score_enabled ? "left-5" : "left-0.5"}`} />
              </button>
            </div>
            <div className="bg-white2 rounded-2xl p-4">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="text-sm text-ink font-medium flex items-center gap-2 mb-1"><Bell size={15} /> {t("settings_notifications")}</div>
                  <p className="text-xs text-muted">
                    {notifStatus === "checking" ? t("settings_notifications_checking") :
                      notifStatus === "done" ? t("settings_notifications_done") :
                      notifStatus === "blocked" ? t("settings_notifications_blocked") :
                      notifStatus === "unsupported" ? t("settings_notifications_unsupported") :
                      notifStatus === "ios-install" ? t("settings_notifications_ios_install") :
                      t("settings_notifications_desc")}
                  </p>
                </div>
                {notifStatus === "done" && (
                  <span className="text-[11px] font-medium text-ink bg-paper border border-border rounded-full px-2.5 py-1 shrink-0">
                    {t("settings_notifications_active")}
                  </span>
                )}
              </div>
              {(notifStatus === "idle" || notifStatus === "error" || notifStatus === "loading") && (
                <button onClick={handleEnableNotifications} disabled={notifStatus === "loading"} className="mt-3 bg-ink text-paper rounded-xl px-4 py-2 text-sm font-medium disabled:opacity-50">
                  {notifStatus === "loading" ? "..." : t("settings_notifications_enable")}
                </button>
              )}
              {notifStatus === "done" && (
                <button onClick={handleDisableNotifications} className="mt-3 text-xs text-muted underline">
                  {t("settings_notifications_disable")}
                </button>
              )}
              {notifStatus === "error" && notifError && <p className="text-xs text-red-700 mt-2">{notifError}</p>}
            </div>
          </div>
        </section>

        <section>
          <div className="mb-3">
            <h2 className="text-base font-semibold text-ink">DABO</h2>
          </div>
          <div className="bg-white2 rounded-2xl p-4 flex items-center justify-between gap-4">
            <div>
              <div className="text-sm text-ink font-medium">{t("share_app_title")}</div>
              <div className="text-xs text-muted">{t("share_app_desc")}</div>
            </div>
            <button onClick={shareApp} className="bg-ink text-paper rounded-xl p-2.5 shrink-0" aria-label={t("share_app_title")}>
              <Share2 size={16} />
            </button>
          </div>
        </section>

        <section>
          <div className="mb-3">
            <h2 className="text-base font-semibold text-ink">{t("settings_section_account")}</h2>
          </div>
          <div className="bg-white2 rounded-2xl p-4">
            <div className="pb-3 mb-3 border-b border-border">
              <div className="text-sm font-medium text-ink">
                {t("settings_export_title")}
              </div>
              <p className="text-xs text-muted mt-1 leading-relaxed">
                {t("settings_export_desc")}
              </p>
              <div className="mt-3 space-y-2">
                <button
                  type="button"
                  onClick={() => void exportMyData("readable")}
                  disabled={exportingData}
                  className="w-full rounded-xl bg-ink px-3 py-2.5 text-sm font-medium text-paper flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <Download size={16} />
                  <span>
                    {exportingData ? "…" : t("settings_export_readable_action")}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => void exportMyData("json")}
                  disabled={exportingData}
                  className="w-full rounded-xl border border-border px-3 py-2.5 text-sm font-medium text-ink flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <Download size={16} />
                  <span>
                    {exportingData ? "…" : t("settings_export_action")}
                  </span>
                </button>
              </div>
            </div>

            <button onClick={signOut} className="w-full text-sm text-ink py-1 flex items-center justify-between">
              <span>{t("settings_signout")}</span><LogOut size={16} className="text-muted" />
            </button>
          </div>
        </section>

        <section>
          <div className="mb-3">
            <h2 className="text-sm font-semibold text-red-700/80">{t("settings_sensitive_actions")}</h2>
            <p className="text-xs text-muted mt-0.5">{t("settings_sensitive_actions_desc")}</p>
          </div>
          <div className="border border-border rounded-2xl p-4 space-y-1">
            <button onClick={() => setConfirmation({ kind: "leave" })} className="w-full py-2.5 text-sm text-muted text-left">
              {t("settings_leave")}
            </button>
            <div className="h-px bg-border" />
            <button onClick={() => setConfirmation({ kind: "delete" })} className="w-full py-2.5 text-sm text-red-700/80 text-left">
              {t("settings_delete_account")}
            </button>
          </div>
        </section>
      </div>

      {feedback && (
        <div className="fixed left-4 right-4 bottom-24 z-50 flex justify-center pointer-events-none">
          <div className={`max-w-sm w-full rounded-2xl border px-4 py-3 text-sm shadow-lg ${feedback.type === "error" ? "border-red-200 bg-paper text-red-700" : "border-border bg-paper text-ink"}`}>
            {feedback.text}
          </div>
        </div>
      )}

      {confirmation && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/35 px-0 sm:px-4" onClick={closeConfirmation}>
          <div className="w-full sm:max-w-md rounded-t-3xl sm:rounded-3xl bg-paper p-5 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="w-10 h-1 rounded-full bg-border mx-auto mb-5 sm:hidden" />
            <h3 className="text-lg font-semibold text-ink">
              {confirmation.kind === "promote" && t("settings_confirm_promote_title").replace("{name}", confirmation.name)}
              {confirmation.kind === "remove" && t("settings_confirm_remove_title").replace("{name}", confirmation.name)}
              {confirmation.kind === "leave" && t("settings_confirm_leave_title").replace("{household}", household.name)}
              {confirmation.kind === "delete" && t("settings_confirm_delete_title")}
            </h3>
            <p className="text-sm text-muted mt-2 leading-relaxed">
              {confirmation.kind === "promote" && t("settings_confirm_promote_desc")}
              {confirmation.kind === "remove" && t("settings_confirm_remove_desc").replace("{name}", confirmation.name)}
              {confirmation.kind === "leave" && t("settings_confirm_leave_desc")}
              {confirmation.kind === "delete" && t("settings_confirm_delete_desc")}
            </p>

            {confirmation.kind === "delete" && (
              <div className="mt-5">
                <label className="block text-xs font-medium text-ink mb-1.5">{t("settings_delete_phrase_label")}</label>
                <input
                  value={deletePhrase}
                  onChange={(e) => setDeletePhrase(e.target.value)}
                  placeholder={t("settings_delete_phrase")}
                  autoComplete="off"
                  className="w-full border border-border rounded-xl bg-white2 px-3 py-2.5 text-sm text-ink outline-none focus:border-ink"
                />
              </div>
            )}

            <div className="flex gap-2 mt-6">
              <button disabled={confirmationLoading} onClick={closeConfirmation} className="flex-1 rounded-xl border border-border px-4 py-2.5 text-sm font-medium text-ink disabled:opacity-50">
                {t("cancel")}
              </button>
              <button
                disabled={confirmationLoading || (confirmation.kind === "delete" && deletePhrase.trim().toUpperCase() !== t("settings_delete_phrase").toUpperCase())}
                onClick={confirmSensitiveAction}
                className={`flex-1 rounded-xl px-4 py-2.5 text-sm font-medium disabled:opacity-40 ${confirmation.kind === "remove" || confirmation.kind === "leave" || confirmation.kind === "delete" ? "bg-red-700 text-white" : "bg-ink text-paper"}`}
              >
                {confirmationLoading ? "…" : confirmation.kind === "promote" ? t("settings_confirm_promote_action") : confirmation.kind === "remove" ? t("settings_confirm_remove_action") : confirmation.kind === "leave" ? t("settings_confirm_leave_action") : t("settings_confirm_delete_action")}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
